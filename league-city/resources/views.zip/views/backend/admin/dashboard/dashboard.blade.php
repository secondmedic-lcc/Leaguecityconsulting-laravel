<div class="row">
    <div class="col-lg-3 col-md-3">
        <div class="card generate-reports">
            <div class="card-body">
                <h6 class="mb-1">Total Contact Request</h6>
                <h6 class="web-clr">{{ $contact_request }}</h6>
            </div>
        </div>
    </div>
    {{-- <div class="col-lg-3 col-md-3">
        <div class="card generate-reports">
            <div class="card-body">
                <h6 class="mb-1">Total Customers</h6>
                <h6 class="web-clr">30</h6>
            </div>
        </div>
    </div> --}}
</div>