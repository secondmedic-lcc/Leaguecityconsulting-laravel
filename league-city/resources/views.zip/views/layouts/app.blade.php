@include('./../backend.layouts.head')

@yield('content')
       
@include('./../backend.layouts.js')