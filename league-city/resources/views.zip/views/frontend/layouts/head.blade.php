<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>League City</title>
    <link rel="stylesheet" href="{{ asset('includes-frontend'); }}/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{ asset('includes-frontend'); }}/css/owl.carousel.min.css">
    <link rel="stylesheet" href="{{ asset('includes-frontend'); }}/css/owl.theme.default.css">
    <link rel="stylesheet" href="{{ asset('includes-frontend'); }}/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('includes-frontend'); }}/css/style.css">
    <link rel="icon" type="image/x-icon" href="{{ asset('includes-frontend'); }}/images/favicon.png">
</head>

<body class="web-overflow">