<section class="page-banner section-padding" style="background-image: url({{ asset('includes-frontend'); }}/images/services-banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <span class="heading-top">Our Blogs</span>
                <h1 class="section-heading">What's New <span class="light">At LeagueCity?</span></h1>
                <p class="mb-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias repellat necessitatibus earum sed officiis?</p>
            </div>
        </div>
    </div>
</section>
<nav aria-label="breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ url('/'); }}">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Blogs</li>
                </ol>
            </div>
        </div>
    </div>
</nav>

<section class="blog section-padding pb-0">
    <div class="container">
        <div class="row g-3">

            @foreach($blog as $b)
            @php $url = url('blogs')."/".Str::slug($b['blog_title']."-".$b['id']);; @endphp
                <div class="col-lg-4 col-md-6">
                    <div class="box">
                        <a href="{{ $url; }}">
                            <div class="image">
                                <img src="{{ ($b['blog_image'] != '' && $b['blog_image'] != null) ? asset($b['blog_image']) : asset('includes-frontend/images/aichatbots.jpg'); }}" alt="AI Chatbots: Transforming Customer Experiences with Digital Companions">
                            </div>
                        </a>
                        <div>
                            <h3><a href="{{ $url; }}">{{ $b['blog_title'] }}</a></h3>
                            <ul class="blog-info-list">
                                <li><span class="text-grey">27 January 2024</span></li>
                                <li>Read Time : <span class="text-grey">{{ $b['read_time'] }}</span></li>
                            </ul>
                            <p class="mb-0"><span>{{ $b['blog_details'] }}</span> <a href="{{ $url; }}" class="web-clr">Read More</a></p>
                        </div>
                    </div>
                </div>
            @endforeach
            
            <div class="pagination-all mt-3">
                {{ $blog->links() }}
            </div>
         
        </div>
    </div>
</section>


@include('frontend.pages.query-form')